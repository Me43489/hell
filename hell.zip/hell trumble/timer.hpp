#pragma once
#include "SDL.h"

/*int fps = 60;
int desiredDelta = 100 / fps;
int avgFPS;
int frame = 0;
int radius = 0;
int CurrFrame;
*/

/*class Timer {
private:
	int starttick;
	int AvgFPS;
public:

};*/