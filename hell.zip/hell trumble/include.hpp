#pragma once
/*********************
		C++ Libs
**********************/
#include <iostream>
#include <string>
#include <stack>
#include <vector>
#include <iterator>
/*********************
		C Libs
**********************/
#include <direct.h>
/*********************
		Macros
**********************/
#include <SDL.h>


