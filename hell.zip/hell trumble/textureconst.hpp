#pragma once

#define BACKROUND "Backround"

/*SDL_Rect Board_Dest = { 0,0,1600,1024 };
SDL_Rect Red_Triangle_Down = { 32,32,98,400 };*/