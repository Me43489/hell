#pragma once

#define DEBUG 1
#define PRINT_CPP sprintf(buffer, "C++ Version: %ld", __cplusplus);